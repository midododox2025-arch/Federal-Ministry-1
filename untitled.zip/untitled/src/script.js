const ADMIN_CODE = "1977";
const PASSWORD = "1986";

let currentUser = "";

// تسجيل الدخول
function login(){

    let code = document.getElementById("loginCode").value;
    let pass = document.getElementById("password").value;

    if(code !== "" && pass === PASSWORD){

        currentUser = code;
        localStorage.setItem("user", code);

        showDashboard();

    } else {
        document.getElementById("error").innerText = "بيانات غير صحيحة";
    }
}

// عرض لوحة التحكم
function showDashboard(){

    document.getElementById("loginBox").style.display = "none";
    document.getElementById("dashboard").style.display = "block";

    currentUser = localStorage.getItem("user");

    if(currentUser !== ADMIN_CODE){
        document.getElementById("adminPanel").style.display = "none";
        document.getElementById("delHead").style.display = "none";
    }

    loadData();
}

// تسجيل خروج
function logout(){
    localStorage.removeItem("user");
    location.reload();
}

// إضافة بيانات (فقط 1977)
function addPerson(){

    if(currentUser !== ADMIN_CODE) return;

    let name = document.getElementById("nameInput").value;
    let rank = document.getElementById("rankInput").value;
    let sector = document.getElementById("sectorInput").value;
    let code = document.getElementById("codeInput").value;

    let data = JSON.parse(localStorage.getItem("data")) || [];

    data.push({name, rank, sector, code});

    localStorage.setItem("data", JSON.stringify(data));

    loadData();
}

// تحميل البيانات
function loadData(){

    let table = document.getElementById("dataTable");
    table.innerHTML = "";

    let data = JSON.parse(localStorage.getItem("data")) || [];

    data.forEach((item, index)=>{

        table.innerHTML += `
        <tr>
            <td>${item.name}</td>
            <td>${item.rank}</td>
            <td>${item.sector}</td>
            <td>${item.code}</td>
            ${currentUser === ADMIN_CODE ? 
            `<td><button class="delBtn" onclick="deleteData(${index})">حذف</button></td>` 
            : ""}
        </tr>
        `;
    });
}

// حذف بيانات
function deleteData(index){

    if(currentUser !== ADMIN_CODE) return;

    let data = JSON.parse(localStorage.getItem("data"));
    data.splice(index,1);

    localStorage.setItem("data", JSON.stringify(data));

    loadData();
}

// تشغيل تلقائي
window.onload = function(){

    if(localStorage.getItem("user")){
        showDashboard();
    }
}